const balanceEl = document.getElementById("balance");
const incomeAmountEl = document.getElementById("income-amount");
const expenseAmountEl = document.getElementById("expense-amount");
const transactionListEl = document.getElementById("transaction-list");
const transactionFormEl = document.getElementById("transaction-form");
const descriptionEl = document.getElementById("description");
const amountEl = document.getElementById("amount"); // Corrected ID to match HTML: "amount" (lowercase 'a')

// Initialize transactions array from local storage or as an empty array
let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

// Function to generate a unique ID for transactions
function generateID() {
    return Math.floor(Math.random() * 100000000);
}

// Function to add a new transaction
function addTransaction(e) {
    e.preventDefault(); // Prevent default form submission behavior (page reload)

    // Get form values
    const description = descriptionEl.value.trim();
    const amount = parseFloat(amountEl.value);

    // Basic validation: Check if description is empty or amount is not a number
    if (description === '' || isNaN(amount)) {
        // Using alert() for simplicity, but a custom message box is recommended for better UX
        alert('Please enter a valid description and amount.');
        return;
    }

    // Create a new transaction object
    const transaction = {
        id: generateID(),
        description,
        amount
    };

    // Add new transaction to the transactions array
    transactions.push(transaction);

    // Add the new transaction to the DOM list
    addTransactionToDOM(transaction);

    // Update balance, income, and expenses
    updateValues();

    // Save transactions to local storage
    updateLocalStorage();

    // Clear form fields
    transactionFormEl.reset(); // Resets all form fields
}

// Function to add transaction to DOM list
function addTransactionToDOM(transaction) {
    // Determine class based on amount (income or expense)
    const sign = transaction.amount < 0 ? 'minus' : 'plus';

    const item = document.createElement('li');
    // Add a 'group' class for Tailwind CSS hover effects on delete button, if applicable
    item.classList.add('transaction', sign); // 'transaction' class from style.css, 'plus' or 'minus' for border color

    item.innerHTML = `
        <span>${transaction.description}</span>
        <span>
            ${formatCurrency(transaction.amount)}
            <button class="delete-btn" onclick="removeTransaction(${transaction.id})">x</button>
        </span>
    `;

    // Prepend the new transaction to the list to show the newest at the top
    transactionListEl.prepend(item);
}

// Function to update the balance, income, and expenses display
function updateValues() {
    // Calculate total amounts
    const amounts = transactions.map(transaction => transaction.amount);

    const total = amounts.reduce((acc, item) => (acc += item), 0);

    const income = amounts
        .filter(item => item > 0)
        .reduce((acc, item) => (acc += item), 0);

    const expense = amounts
        .filter(item => item < 0)
        .reduce((acc, item) => (acc += item), 0);

    // Update DOM elements with formatted currency
    balanceEl.textContent = formatCurrency(total);
    incomeAmountEl.textContent = formatCurrency(income);
    expenseAmountEl.textContent = formatCurrency(expense);
}

// Function to format currency
function formatCurrency(number) {
    // Using 'en-IN' locale for Indian Rupee symbol (₹) and common formatting
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR", // Changed to INR for Indian Rupee
        minimumFractionDigits: 2
    }).format(number);
}

// Function to remove a transaction by ID
function removeTransaction(id) {
    // Filter out the transaction to be removed
    transactions = transactions.filter(transaction => transaction.id !== id);

    updateLocalStorage(); // Update local storage after removal
    init(); // Re-initialize to update the DOM and values
}

// Function to update local storage
function updateLocalStorage() {
    localStorage.setItem('transactions', JSON.stringify(transactions)); // Corrected typo here
}

// Initialize the app: Load transactions and update UI
function init() {
    transactionListEl.innerHTML = ''; // Clear existing list items before re-rendering

    // Add transactions to DOM, oldest first, so reverse the array for display if needed
    // The current addTransactionToDOM prepends, so no need to reverse here if you want newest on top
    transactions.forEach(addTransactionToDOM);
    updateValues(); // Update balance, income, expenses
}

// Event Listener for form submission
transactionFormEl.addEventListener("submit", addTransaction);

// Initial app setup when the script loads
init();
