<?php
// Include database connection FIRST
include 'config.php';
// Include header, which handles session and login checks
include 'header.php';

// Initialize variables with default/fallback values
$total_employees = 0;
$total_inventory_items = 0;
$total_inventory_value = 0;
$total_orders = 0;
$pending_orders = 0;
$completed_orders = 0;

// --- Fetch KPI Data from Database ---
// Fetch Employee Count
$sql_employees = "SELECT COUNT(id) AS total FROM employees";
if ($result = $conn->query($sql_employees)) {
    $total_employees = $result->fetch_assoc()['total'];
    $result->free();
}

// Fetch Inventory Data
$sql_inventory = "SELECT COUNT(id) AS total_items, SUM(quantity * price_per_unit) AS total_value FROM inventory";
if ($result = $conn->query($sql_inventory)) {
    $row = $result->fetch_assoc();
    $total_inventory_items = $row['total_items'] ?? 0;
    $total_inventory_value = $row['total_value'] ?? 0;
    $result->free();
}

// Fetch Order Data
$sql_orders_total = "SELECT COUNT(id) AS total FROM orders";
if ($result = $conn->query($sql_orders_total)) {
    $total_orders = $result->fetch_assoc()['total'];
    $result->free();
}

$sql_orders_pending = "SELECT COUNT(id) AS total FROM orders WHERE status = 'Pending'";
if ($result = $conn->query($sql_orders_pending)) {
    $pending_orders = $result->fetch_assoc()['total'];
    $result->free();
}

$sql_orders_completed = "SELECT COUNT(id) AS total FROM orders WHERE status = 'Completed'";
if ($result = $conn->query($sql_orders_completed)) {
    $completed_orders = $result->fetch_assoc()['total'];
    $result->free();
}


// --- Fetch Recent Activities from activity_log table (NEW) ---
$activities = [];
$sql_activities = "SELECT activity_type, activity_message, timestamp FROM activity_log ORDER BY timestamp DESC LIMIT 5";
if ($result = $conn->query($sql_activities)) {
    while ($row = $result->fetch_assoc()) {
        $activities[] = $row;
    }
    $result->free();
}

// Helper function to get an icon and color based on the activity type
function getActivityIcon($type) {
    switch (true) {
        case strpos($type, 'employee_added') !== false:
            return ['icon' => 'fa-user-plus', 'color' => 'info-icon'];
        case strpos($type, 'employee_updated') !== false:
            return ['icon' => 'fa-user-edit', 'color' => 'warning-icon'];
        case strpos($type, 'employee_deleted') !== false:
            return ['icon' => 'fa-user-minus', 'color' => 'error-icon'];
        
        case strpos($type, 'inventory_added') !== false:
            return ['icon' => 'fa-plus-circle', 'color' => 'primary-icon'];
        case strpos($type, 'inventory_updated') !== false:
            return ['icon' => 'fa-box', 'color' => 'warning-icon'];
        case strpos($type, 'inventory_deleted') !== false:
            return ['icon' => 'fa-trash-alt', 'color' => 'error-icon'];
            
        case strpos($type, 'order_added') !== false:
            return ['icon' => 'fa-shipping-fast', 'color' => 'primary-icon'];
        case strpos($type, 'order_updated') !== false:
            return ['icon' => 'fa-dolly', 'color' => 'info-icon'];
        case strpos($type, 'order_deleted') !== false:
            return ['icon' => 'fa-times-circle', 'color' => 'error-icon'];

        default:
            return ['icon' => 'fa-info-circle', 'color' => 'info-icon'];
    }
}
?>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Dashboard</h1>

    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-icon"><i class="fas fa-users"></i></div>
            <div class="kpi-info">
                <span>Total Employees</span>
                <span class="kpi-value"><?php echo $total_employees; ?></span>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon"><i class="fas fa-box"></i></div>
            <div class="kpi-info">
                <span>Inventory Items</span>
                <span class="kpi-value"><?php echo $total_inventory_items; ?></span>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon"><i class="fas fa-dollar-sign"></i></div>
            <div class="kpi-info">
                <span>Inventory Value</span>
                <span class="kpi-value">$<?php echo number_format($total_inventory_value, 2); ?></span>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon"><i class="fas fa-shipping-fast"></i></div>
            <div class="kpi-info">
                <span>Total Orders</span>
                <span class="kpi-value"><?php echo $total_orders; ?></span>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon pending"><i class="fas fa-clock"></i></div>
            <div class="kpi-info">
                <span>Pending Orders</span>
                <span class="kpi-value"><?php echo $pending_orders; ?></span>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon completed"><i class="fas fa-check-circle"></i></div>
            <div class="kpi-info">
                <span>Completed Orders</span>
                <span class="kpi-value"><?php echo $completed_orders; ?></span>
            </div>
        </div>
    </div>

    <div class="recent-activity-section">
        <h2>Recent Activities</h2>
        <div class="activity-log">
            <?php if (empty($activities)): ?>
                <p>No recent activities to display.</p>
            <?php else: ?>
                <?php foreach ($activities as $activity):
                    $icon_details = getActivityIcon($activity['activity_type']);
                ?>
                    <p>
                        <i class="fas <?php echo $icon_details['icon']; ?> <?php echo $icon_details['color']; ?>"></i>
                        <span><?php echo htmlspecialchars($activity['activity_message']); ?></span>
                    </p>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

</div>

</div>
<script>
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (mobileMenuToggle && sidebar && sidebarOverlay) {
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });

        // Close sidebar if window is resized to desktop size
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) { // Assuming 768px is our mobile breakpoint
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            }
        });
    }
</script> 
</body>
</html>