<?php
session_start();

// Hardcoded credentials for demonstration without a database
$correct_username = 'admin';
$correct_password = 'password123';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $correct_username && $password === $correct_password) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header("location: dashboard.php"); // Redirect to dashboard on success
        exit;
    } else {
        header("location: index.php?error=1"); // Redirect back to login with error
        exit;
    }
} else {
    // If someone tries to access this page directly without POST, redirect to login
    header("location: index.php");
    exit;
}
?>