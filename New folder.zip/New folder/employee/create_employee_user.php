<?php
include 'config.php'; // Include database connection

// --- Function to generate a random password ---
function generateRandomPassword($length = 12) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()-_=+';
    $password = '';
    $charactersLength = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $charactersLength - 1)];
    }
    return $password;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = $_POST['employee_id'] ?? '';
    $username = $_POST['username'] ?? '';
    
    if (empty($employee_id) || empty($username)) {
        $message = "<p class='message error'>Please select an employee and provide a username.</p>";
    } else {
        // Generate a random password
        $random_password_plaintext = generateRandomPassword();
        $hashed_password = password_hash($random_password_plaintext, PASSWORD_DEFAULT);

        // Check if employee_id already has a user account
        $check_sql = "SELECT id FROM users WHERE employee_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $employee_id);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $message = "<p class='message error'>Error: This employee already has a user account.</p>";
            $check_stmt->close();
        } else {
            $check_stmt->close(); // Close previous statement

            // Insert into users table
            $sql = "INSERT INTO users (username, password, employee_id, role) VALUES (?, ?, ?, 'employee')";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssi", $username, $hashed_password, $employee_id);
                if ($stmt->execute()) {
                    $message = "<p class='message success'>User account for " . htmlspecialchars($username) . " created successfully!</p>";
                    $message .= "<p class='message success'><strong>Initial Password (IMPORTANT - copy this!):</strong> <code>" . htmlspecialchars($random_password_plaintext) . "</code></p>";
                } else {
                    if ($stmt->errno == 1062) { // Duplicate entry for username
                        $message = "<p class='message error'>Error: Username '" . htmlspecialchars($username) . "' already exists. Please choose another.</p>";
                    } else {
                        $message = "<p class='message error'>Error creating user: " . $stmt->error . "</p>";
                    }
                }
                $stmt->close();
            } else {
                $message = "<p class='message error'>Database error: Could not prepare statement.</p>";
            }
        }
    }
}

// Fetch employees who do NOT yet have a user account
$employees_without_user = [];
$sql_employees = "SELECT e.id, e.name
                  FROM employees e
                  LEFT JOIN users u ON e.id = u.employee_id
                  WHERE u.employee_id IS NULL
                  ORDER BY e.name ASC";
if ($result_employees = $conn->query($sql_employees)) {
    while ($row_employee = $result_employees->fetch_assoc()) {
        $employees_without_user[] = $row_employee;
    }
    $result_employees->free();
} else {
    $message .= "<p class='message error'>Error fetching employees: " . $conn->error . "</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Employee User Account</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body.admin-tools-body {
            background-color: var(--body-bg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 30px;
        }
        .admin-card {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 600px;
            border-top: 5px solid var(--primary-color);
        }
        .admin-card h2 {
            font-size: 28px;
            margin-bottom: 25px;
            color: var(--text-dark);
            text-align: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }
        .admin-card .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .admin-card .form-group label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 8px;
            display: block;
        }
        .admin-card .form-group select,
        .admin-card .form-group input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            color: var(--text-dark);
            background-color: var(--input-bg);
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .admin-card .form-group select:focus,
        .admin-card .form-group input[type="text"]:focus {
            outline: none;
            border-color: var(--input-border-focus);
            box-shadow: 0 0 0 3px rgba(0, 121, 107, 0.2);
        }
        .admin-card button {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            margin-top: 20px;
        }
        .admin-card button:hover {
            background-color: var(--primary-hover);
            box-shadow: 0 4px 15px rgba(0, 121, 107, 0.3);
        }
        .message {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 8px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            text-align: left;
        }
        .message i { font-size: 18px; }
        .message.success { background-color: var(--success-bg); color: var(--success-color); border: 1px solid #a5d6a7; }
        .message.error { background-color: var(--error-bg); color: var(--error-color); border: 1px solid #ef9a9a; }
        .message code {
            background-color: #f0f0f0;
            padding: 5px 10px;
            border-radius: 5px;
            font-family: 'Consolas', monospace;
            font-weight: 700;
            color: var(--text-dark);
            white-space: nowrap;
            overflow-x: auto;
            display: inline-block;
            margin-top: 5px;
        }
        .no-employees-message {
            text-align: center;
            padding: 20px;
            background-color: #fdfae6;
            border: 1px solid #ffe082;
            border-radius: 8px;
            color: #d84315;
            font-weight: 500;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="admin-tools-body">
    <div class="admin-card">
        <h2>Create Employee User Account</h2>
        <?php echo $message; ?>

        <?php if (empty($employees_without_user)): ?>
            <div class="no-employees-message">
                All employees already have a user account, or no employees exist.
                Please add employees first or delete existing user accounts if you wish to re-create them.
            </div>
        <?php else: ?>
            <form method="POST" action="create_employee_user.php">
                <div class="form-group">
                    <label for="employee_id">Select Employee:</label>
                    <select id="employee_id" name="employee_id" required>
                        <option value="">-- Select an Employee --</option>
                        <?php foreach ($employees_without_user as $employee): ?>
                            <option value="<?php echo htmlspecialchars($employee['id']); ?>">
                                <?php echo htmlspecialchars($employee['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="username">Desired Username:</label>
                    <input type="text" id="username" name="username" placeholder="e.g., john.doe" required>
                </div>
                <button type="submit">Create User Account</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>