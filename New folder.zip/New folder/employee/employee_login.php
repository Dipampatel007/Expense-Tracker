<?php
session_start(); // Start the session at the very beginning
include '../config.php' ;
//include '../style.css';// Include database connection

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username'] ?? '');
    $password = $_POST['password'] ?? ''; // Do not htmlspecialchars password before hashing/verification

    if (empty($username) || empty($password)) {
        $message = "Please enter both username and password.";
    } else {
        // Query the database for the user
        $sql = "SELECT id, password, employee_id, role FROM users WHERE username = ? AND role = 'employee'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            // Verify the hashed password
            if (password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['employee_logged_in'] = true;
                $_SESSION['employee_id'] = $user['employee_id'];
                $_SESSION['employee_username'] = $user['username'];
                $_SESSION['employee_role'] = $user['role']; // Will be 'employee'

                header('Location: employee_self_attendance.php');
                exit();
            } else {
                $message = "Invalid username or password.";
            }
        } else {
            $message = "Invalid username or password.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Login</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body class="login-body">
    <div class="login-container">
        <div class="login-box">
            <img src="logo.png" alt="Factory Logo" class="logo"> <h1>Employee Login</h1>
            <p class="welcome-text">Access your attendance portal.</p>

            <?php if ($message): ?>
                <div class="message error" style="margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form action="employee_login.php" method="POST">
                <div class="form-group input-group">
                    <input type="text" name="username" placeholder="Username" required>
                </div>
                <div class="form-group input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>