<?php
// Ensure config.php is included FIRST to establish database connection ($conn)
// and make log_activity() function available.
include 'config.php'; 
// Then include header.php which handles session_start() and login checks.
include 'header.php';

$message = '';
$message_type = '';

// --- Handle Form Submissions (Add, Edit, Delete Employee) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_employee'])) {
        $name = htmlspecialchars($_POST['name']);
        $position = htmlspecialchars($_POST['position']);
        $contact_info = htmlspecialchars($_POST['contact_info']);
        $hire_date = htmlspecialchars($_POST['hire_date']);

        if (!empty($name) && !empty($position) && !empty($hire_date)) {
            $sql = "INSERT INTO employees (name, position, contact_info, hire_date) VALUES (?, ?, ?, ?)";
            // Prepare a NEW statement for this specific ADD operation
            $stmt = $conn->prepare($sql); 
            if ($stmt) {
                $stmt->bind_param("ssss", $name, $position, $contact_info, $hire_date);
                if ($stmt->execute()) {
                    // Get the ID of the newly inserted employee BEFORE logging
                    $new_employee_id = $stmt->insert_id; 
                    $message = "Employee added successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'employee_added', "New employee '" . $name . "' was added.", $new_employee_id);
                } else {
                    $message = "Error adding employee: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['edit_employee'])) {
        $id = htmlspecialchars($_POST['employee_id']);
        $name = htmlspecialchars($_POST['name']);
        $position = htmlspecialchars($_POST['position']);
        $contact_info = htmlspecialchars($_POST['contact_info']);
        $hire_date = htmlspecialchars($_POST['hire_date']);

        if (!empty($id) && is_numeric($id) && !empty($name) && !empty($position) && !empty($hire_date)) {
            $sql = "UPDATE employees SET name = ?, position = ?, contact_info = ?, hire_date = ? WHERE id = ?";
            // Prepare a NEW statement for this specific EDIT operation
            $stmt = $conn->prepare($sql); 
            if ($stmt) {
                $stmt->bind_param("ssssi", $name, $position, $contact_info, $hire_date, $id);
                if ($stmt->execute()) {
                    $message = "Employee updated successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'employee_updated', "Employee details for '" . $name . "' (ID: " . $id . ") were updated.", $id);
                } else {
                    $message = "Error updating employee: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly for editing.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['delete_employee'])) {
        $id = htmlspecialchars($_POST['employee_id']);

        if (!empty($id) && is_numeric($id)) {
            // First, get employee name for logging before deletion
            $employee_name_to_delete = "Unknown";
            $sql_get_name = "SELECT name FROM employees WHERE id = ?";
            $stmt_get_name = $conn->prepare($sql_get_name);
            if ($stmt_get_name) {
                $stmt_get_name->bind_param("i", $id);
                $stmt_get_name->execute();
                $result_name = $stmt_get_name->get_result();
                if ($row_name = $result_name->fetch_assoc()) {
                    $employee_name_to_delete = $row_name['name'];
                }
                $stmt_get_name->close();
            }


            $sql = "DELETE FROM employees WHERE id = ?";
            // Prepare a NEW statement for this specific DELETE operation
            $stmt = $conn->prepare($sql); 
            if ($stmt) {
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    $message = "Employee deleted successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'employee_deleted', "Employee '" . $employee_name_to_delete . "' (ID: " . $id . ") was deleted.", $id);
                } else {
                    $message = "Error deleting employee: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Invalid employee ID for deletion.";
            $message_type = 'error';
        }
    }
}

// --- Fetch Employees for Display ---
$employees = [];
$sql_fetch = "SELECT id, name, position, contact_info, hire_date FROM employees ORDER BY name ASC";
if ($result = $conn->query($sql_fetch)) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    $result->free(); // Free the result set
} else {
    // Only set message if there was a problem fetching, not just no employees
    if (empty($employees) && $conn->error) {
        $message = "Error fetching employees: " . $conn->error;
        $message_type = 'error';
    }
}

?>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Employee Management</h1>

    <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>">
            <i class="fas <?php echo ($message_type == 'success' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <button class="btn-add" onclick="openAddModal()"><i class="fas fa-plus"></i> Add New Employee</button>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Contact Info</th>
                    <th>Hire Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($employees)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">No employees found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($employees as $employee): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($employee['id']); ?></td>
                            <td><?php echo htmlspecialchars($employee['name']); ?></td>
                            <td><?php echo htmlspecialchars($employee['position']); ?></td>
                            <td><?php echo htmlspecialchars($employee['contact_info']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($employee['hire_date'])); ?></td>
                            <td>
                                <button class="btn-edit" onclick="openEditModal(
                                    <?php echo $employee['id']; ?>,
                                    '<?php echo htmlspecialchars($employee['name'], ENT_QUOTES); ?>',
                                    '<?php echo htmlspecialchars($employee['position'], ENT_QUOTES); ?>',
                                    '<?php echo htmlspecialchars($employee['contact_info'], ENT_QUOTES); ?>',
                                    '<?php echo date('Y-m-d', strtotime($employee['hire_date'])); ?>'
                                )"><i class="fas fa-edit"></i> Edit</button>
                                <form method="POST" action="employees.php" style="display:inline-block;">
                                    <input type="hidden" name="employee_id" value="<?php echo htmlspecialchars($employee['id']); ?>">
                                    <button type="submit" name="delete_employee" class="btn-delete" onclick="return confirm('Are you sure you want to delete this employee? This will also delete their attendance records.');"><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeAddModal()">&times;</span>
            <h2>Add New Employee</h2>
            <form method="POST" action="employees.php">
                <div class="form-group">
                    <label for="add_name">Name</label>
                    <input type="text" id="add_name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="add_position">Position</label>
                    <input type="text" id="add_position" name="position" required>
                </div>
                <div class="form-group">
                    <label for="add_contact_info">Contact Info</label>
                    <input type="text" id="add_contact_info" name="contact_info">
                </div>
                <div class="form-group">
                    <label for="add_hire_date">Hire Date</label>
                    <input type="date" id="add_hire_date" name="hire_date" required>
                </div>
                <button type="submit" name="add_employee" class="btn-modal-save">Add Employee</button>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeEditModal()">&times;</span>
            <h2>Edit Employee</h2>
            <form method="POST" action="employees.php">
                <input type="hidden" id="edit_employee_id" name="employee_id">
                <div class="form-group">
                    <label for="edit_name">Name</label>
                    <input type="text" id="edit_name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="edit_position">Position</label>
                    <input type="text" id="edit_position" name="position" required>
                </div>
                <div class="form-group">
                    <label for="edit_contact_info">Contact Info</label>
                    <input type="text" id="edit_contact_info" name="contact_info">
                </div>
                <div class="form-group">
                    <label for="edit_hire_date">Hire Date</label>
                    <input type="date" id="edit_hire_date" name="hire_date" required>
                </div>
                <button type="submit" name="edit_employee" class="btn-modal-save">Save Changes</button>
            </form>
        </div>
    </div>

</div>

<script>
    // --- Modal Logic ---
    function openAddModal() {
        // Optional: Set default hire date to today
        document.getElementById('add_hire_date').valueAsDate = new Date();
        document.getElementById('addModal').style.display = 'block';
    }
    function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }

    function openEditModal(id, name, position, contact_info, hire_date) {
        document.getElementById('edit_employee_id').value = id;
        document.getElementById('edit_name').value = name;
        document.getElementById('edit_position').value = position;
        document.getElementById('edit_contact_info').value = contact_info;
        document.getElementById('edit_hire_date').value = hire_date;
        document.getElementById('editModal').style.display = 'block';
    }
    function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target == document.getElementById('addModal')) { closeAddModal(); }
        if (event.target == document.getElementById('editModal')) { closeEditModal(); }
    }
</script>
<script>
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (mobileMenuToggle && sidebar && sidebarOverlay) {
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });

        // Close sidebar if window is resized to desktop size
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) { // Assuming 768px is our mobile breakpoint
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            }
        });
    }
</script>
</body>
</html>