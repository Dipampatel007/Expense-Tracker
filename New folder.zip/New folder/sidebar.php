<div class="sidebar">
    <div class="logo-details">
        <i class="fas fa-industry"></i>
        <span class="logo_name">Factory OS</span>
    </div>
    <ul class="nav-links">
        <?php $current_page = basename($_SERVER['PHP_SELF']); ?>

        <li>
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="fas fa-th-large"></i>
                <span class="link_name">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="employees.php" class="<?php echo ($current_page == 'employees.php') ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>
                <span class="link_name">Employees</span>
            </a>
        </li>
        <li>
    <a href="employees.php" class="<?php echo ($currentPage == 'employees.php') ? 'active' : ''; ?>">
        <i class="fas fa-users"></i>
        <span class="link_name">Employee Management</span>
    </a>
</li>
<li>
    <a href="employee_attendance.php" class="<?php echo ($currentPage == 'employee_attendance.php') ? 'active' : ''; ?>">
        <i class="fas fa-calendar-check"></i>
        <span class="link_name">Employee Attendance</span>
    </a>
</li>
        <li>
            <a href="inventory.php" class="<?php echo ($current_page == 'inventory.php') ? 'active' : ''; ?>">
                <i class="fas fa-box"></i>
                <span class="link_name">Inventory</span>
            </a>
        </li>
        <li>
            <a href="orders.php" class="<?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">
                <i class="fas fa-shipping-fast"></i>
                <span class="link_name">Orders</span>
            </a>
        </li>
        <li>
            <a href="reports.php" class="<?php echo ($current_page == 'reports.php') ? 'active' : ''; ?>"> <i class="fas fa-chart-line"></i>
                <span class="link_name">Reports</span>
            </a>
        </li>
       <li>
            <a href="settings.php" class="<?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i>
                <span class="link_name">Settings</span>
            </a>
        </li>
        <li>
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span class="link_name">Logout</span>
            </a>
        </li>
    </ul>
</div>