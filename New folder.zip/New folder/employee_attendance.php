<?php
// Include database connection FIRST
include 'config.php';
// Include header, which handles session_start() and login check
include 'header.php';

// $conn variable is available from config.php

$message = '';
$message_type = '';

// --- Handle Form Submissions ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_attendance'])) {
        // Add Attendance Logic (INSERT into database)
        $employee_id = htmlspecialchars($_POST['employee_id']);
        $attendance_date = htmlspecialchars($_POST['attendance_date']);
        $status = htmlspecialchars($_POST['status']);
        $notes = htmlspecialchars($_POST['notes']);

        if (!empty($employee_id) && is_numeric($employee_id) && !empty($attendance_date) && !empty($status)) {
            $sql = "INSERT INTO employee_attendance (employee_id, attendance_date, status, notes) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("isss", $employee_id, $attendance_date, $status, $notes); // i=integer, s=string
                if ($stmt->execute()) {
                    $message = "Attendance record added successfully!";
                    $message_type = 'success';
                } else {
                    if ($stmt->errno == 1062) { // MySQL error code for duplicate entry
                        $message = "Error: An attendance record for this employee on this date already exists.";
                    } else {
                        $message = "Error adding attendance record: " . $stmt->error;
                    }
                    $message_type = 'error';
                }
                $stmt->close();
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['edit_attendance'])) {
        // Edit Attendance Logic (UPDATE database)
        $id = htmlspecialchars($_POST['attendance_id']);
        $employee_id = htmlspecialchars($_POST['employee_id']);
        $attendance_date = htmlspecialchars($_POST['attendance_date']);
        $status = htmlspecialchars($_POST['status']);
        $notes = htmlspecialchars($_POST['notes']);

        if (!empty($id) && is_numeric($id) && !empty($employee_id) && is_numeric($employee_id) && !empty($attendance_date) && !empty($status)) {
            $sql = "UPDATE employee_attendance SET employee_id = ?, attendance_date = ?, status = ?, notes = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("isssi", $employee_id, $attendance_date, $status, $notes, $id);
                if ($stmt->execute()) {
                    $message = "Attendance record updated successfully!";
                    $message_type = 'success';
                } else {
                     if ($stmt->errno == 1062) { // MySQL error code for duplicate entry
                        $message = "Error: An attendance record for this employee on this date already exists. Please choose a different date or employee.";
                    } else {
                        $message = "Error updating attendance record: " . $stmt->error;
                    }
                    $message_type = 'error';
                }
                $stmt->close();
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly for editing.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['delete_attendance'])) {
        // Delete Attendance Logic (DELETE from database)
        $id = htmlspecialchars($_POST['attendance_id']);

        if (!empty($id) && is_numeric($id)) {
            $sql = "DELETE FROM employee_attendance WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("i", $id); // i=integer
                if ($stmt->execute()) {
                    $message = "Attendance record deleted successfully!";
                    $message_type = 'success';
                } else {
                    $message = "Error deleting attendance record: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close();
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Invalid attendance ID for deletion.";
            $message_type = 'error';
        }
    }
}

// --- Fetch Employees for the dropdown (from database) ---
$employees_list = [];
$sql_employees = "SELECT id, name FROM employees ORDER BY name ASC";
if ($result_employees = $conn->query($sql_employees)) {
    while ($row_employee = $result_employees->fetch_assoc()) {
        $employees_list[] = $row_employee;
    }
    $result_employees->free();
} else {
    $message = "Error fetching employees: " . $conn->error;
    $message_type = 'error';
}


// --- Fetch Attendance Records for Display (from database) ---
$attendance_records = [];
$sql_fetch = "SELECT ea.id, ea.employee_id, e.name AS employee_name, ea.attendance_date, ea.status, ea.notes
              FROM employee_attendance ea
              JOIN employees e ON ea.employee_id = e.id
              ORDER BY ea.attendance_date DESC, e.name ASC";
if ($result = $conn->query($sql_fetch)) {
    while ($row = $result->fetch_assoc()) {
        $attendance_records[] = $row;
    }
    $result->free();
} else {
    $message = "Error fetching attendance records: " . $conn->error;
    $message_type = 'error';
}

?>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Employee Attendance</h1>

    <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>">
            <i class="fas <?php echo ($message_type == 'success' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <button class="btn-add" onclick="openAddModal()"><i class="fas fa-plus"></i> Add New Attendance</button>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Employee Name</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($attendance_records)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">No attendance records found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($attendance_records as $record): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($record['id']); ?></td>
                            <td><?php echo htmlspecialchars($record['employee_name']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($record['attendance_date'])); ?></td>
                            <td>
                                <span class="status <?php echo strtolower($record['status']); ?>">
                                    <?php echo htmlspecialchars($record['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($record['notes']); ?></td>
                            <td>
                                <button class="btn-edit" onclick="openEditModal(
                                    <?php echo $record['id']; ?>,
                                    <?php echo $record['employee_id']; ?>,
                                    '<?php echo date('Y-m-d', strtotime($record['attendance_date'])); ?>',
                                    '<?php echo htmlspecialchars($record['status']); ?>',
                                    '<?php echo htmlspecialchars($record['notes'], ENT_QUOTES); ?>'
                                )"><i class="fas fa-edit"></i> Edit</button>
                                <form method="POST" action="employee_attendance.php" style="display:inline-block;">
                                    <input type="hidden" name="attendance_id" value="<?php echo htmlspecialchars($record['id']); ?>">
                                    <button type="submit" name="delete_attendance" class="btn-delete" onclick="return confirm('Are you sure you want to delete this attendance record?');"><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeAddModal()">&times;</span>
            <h2>Add New Attendance Record</h2>
            <form method="POST" action="employee_attendance.php">
                <div class="form-group">
                    <label for="add_employee_id">Employee</label>
                    <select id="add_employee_id" name="employee_id" required>
                        <option value="">Select Employee</option>
                        <?php foreach ($employees_list as $employee): ?>
                            <option value="<?php echo htmlspecialchars($employee['id']); ?>">
                                <?php echo htmlspecialchars($employee['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="add_attendance_date">Date</label>
                    <input type="date" id="add_attendance_date" name="attendance_date" required>
                </div>
                <div class="form-group">
                    <label for="add_status">Status</label>
                    <select id="add_status" name="status" required>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                        <option value="Late">Late</option>
                        <option value="Leave">Leave</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="add_notes">Notes (Optional)</label>
                    <textarea id="add_notes" name="notes" rows="3"></textarea>
                </div>
                <button type="submit" name="add_attendance" class="btn-modal-save">Add Attendance</button>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeEditModal()">&times;</span>
            <h2>Edit Attendance Record</h2>
            <form method="POST" action="employee_attendance.php">
                <input type="hidden" id="edit_attendance_id" name="attendance_id">
                <div class="form-group">
                    <label for="edit_employee_id">Employee</label>
                    <select id="edit_employee_id" name="employee_id" required>
                        <option value="">Select Employee</option>
                        <?php foreach ($employees_list as $employee): ?>
                            <option value="<?php echo htmlspecialchars($employee['id']); ?>">
                                <?php echo htmlspecialchars($employee['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_attendance_date">Date</label>
                    <input type="date" id="edit_attendance_date" name="attendance_date" required>
                </div>
                <div class="form-group">
                    <label for="edit_status">Status</label>
                    <select id="edit_status" name="status" required>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                        <option value="Late">Late</option>
                        <option value="Leave">Leave</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_notes">Notes (Optional)</label>
                    <textarea id="edit_notes" name="notes" rows="3"></textarea>
                </div>
                <button type="submit" name="edit_attendance" class="btn-modal-save">Save Changes</button>
            </form>
        </div>
    </div>

</div>

<script>
    // --- Modal Logic ---
    function openAddModal() {
        // Set default date to today for convenience
        document.getElementById('add_attendance_date').valueAsDate = new Date();
        document.getElementById('addModal').style.display = 'block';
    }
    function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }

    function openEditModal(id, employee_id, date, status, notes) {
        document.getElementById('edit_attendance_id').value = id;
        document.getElementById('edit_employee_id').value = employee_id;
        document.getElementById('edit_attendance_date').value = date;
        document.getElementById('edit_status').value = status;
        document.getElementById('edit_notes').value = notes;
        document.getElementById('editModal').style.display = 'block';
    }
    function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target == document.getElementById('addModal')) { closeAddModal(); }
        if (event.target == document.getElementById('editModal')) { closeEditModal(); }
    }
</script>
</body>
</html>