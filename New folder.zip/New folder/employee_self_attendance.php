<?php
session_start(); // Start the session at the very beginning
include 'config.php'; // Include database connection

// --- Check if employee is logged in ---
if (!isset($_SESSION['employee_logged_in']) || $_SESSION['employee_logged_in'] !== true || $_SESSION['employee_role'] !== 'employee') {
    // If not logged in as an employee, redirect to employee login page
    header('Location: employee_login.php');
    exit();
}

// Get the logged-in employee's ID from the session
$logged_in_employee_id = $_SESSION['employee_id'];
$logged_in_employee_username = $_SESSION['employee_username'];

$message = '';
$message_type = '';

// --- Fetch Employee Name for Display ---
$employee_name = "Unknown Employee";
$sql_employee_name = "SELECT name FROM employees WHERE id = ?";
$stmt_name = $conn->prepare($sql_employee_name);
$stmt_name->bind_param("i", $logged_in_employee_id);
$stmt_name->execute();
$result_name = $stmt_name->get_result();
if ($result_name->num_rows > 0) {
    $row_name = $result_name->fetch_assoc();
    $employee_name = $row_name['name'];
}
$stmt_name->close();


// --- Handle Form Submission ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_attendance'])) {
    // The employee_id is now taken from the session, not the form
    $attendance_date = htmlspecialchars($_POST['attendance_date']);
    $status = htmlspecialchars($_POST['status']);
    $notes = htmlspecialchars($_POST['notes']);

    if (!empty($attendance_date) && !empty($status)) {
        // Check if a record for this employee and date already exists
        $check_sql = "SELECT id FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("is", $logged_in_employee_id, $attendance_date);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $message = "Error: Your attendance for " . $attendance_date . " has already been recorded.";
            $message_type = 'error';
        } else {
            $sql = "INSERT INTO employee_attendance (employee_id, attendance_date, status, notes) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("isss", $logged_in_employee_id, $attendance_date, $status, $notes);
                if ($stmt->execute()) {
                    $message = "Your attendance for " . $attendance_date . " has been recorded as " . $status . ". Thank you!";
                    $message_type = 'success';
                } else {
                    $message = "Error recording attendance: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close();
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        }
        $check_stmt->close();
    } else {
        $message = "Please select a date and status.";
        $message_type = 'error';
    }
}

// --- Fetch *only the logged-in employee's* attendance records for display ---
$employee_attendance_history = [];
$sql_history = "SELECT id, attendance_date, status, notes
                FROM employee_attendance
                WHERE employee_id = ?
                ORDER BY attendance_date DESC";
$stmt_history = $conn->prepare($sql_history);
$stmt_history->bind_param("i", $logged_in_employee_id);
$stmt_history->execute();
$result_history = $stmt_history->get_result();
while ($row_history = $result_history->fetch_assoc()) {
    $employee_attendance_history[] = $row_history;
}
$stmt_history->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance - <?php echo htmlspecialchars($employee_name); ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Specific styles for this self-attendance page to make it standalone */
        body.attendance-body {
            background-color: var(--body-bg);
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Align to top for scrollable content */
            min-height: 100vh;
            margin: 0;
            padding: 30px; /* Add padding for overall page */
        }
        .attendance-container {
            width: 100%;
            max-width: 800px; /* Wider container for form + history */
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        .attendance-card, .attendance-history-card {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-top: 5px solid var(--primary-color);
        }
        .attendance-card h2, .attendance-history-card h2 {
            font-size: 24px;
            margin-bottom: 25px;
            color: var(--text-dark);
            text-align: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }
        .attendance-card .form-group {
            text-align: left;
            margin-bottom: 20px;
        }
        .attendance-card .form-group label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 8px;
            display: block;
        }
        .attendance-card .form-group select,
        .attendance-card .form-group input[type="date"],
        .attendance-card .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            color: var(--text-dark);
            background-color: var(--input-bg);
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .attendance-card .form-group select:focus,
        .attendance-card .form-group input[type="date"]:focus,
        .attendance-card .form-group textarea:focus {
            outline: none;
            border-color: var(--input-border-focus);
            box-shadow: 0 0 0 3px rgba(0, 121, 107, 0.2);
        }
        .attendance-card button {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            margin-top: 20px;
        }
        .attendance-card button:hover {
            background-color: var(--primary-hover);
            box-shadow: 0 4px 15px rgba(0, 121, 107, 0.3);
        }
        .message {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 8px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            text-align: left;
        }
        .message i { font-size: 18px; }
        .message.success { background-color: var(--success-bg); color: var(--success-color); border: 1px solid #a5d6a7; }
        .message.error { background-color: var(--error-bg); color: var(--error-color); border: 1px solid #ef9a9a; }

        .welcome-message {
            text-align: center;
            margin-bottom: 25px;
            font-size: 18px;
            color: var(--text-dark);
            font-weight: 500;
        }
        .welcome-message span {
            color: var(--primary-color);
            font-weight: 700;
        }

        /* Attendance History Table */
        .attendance-history-card .table-container {
            padding: 0; /* Remove padding from .table-container inside a card */
            box-shadow: none; /* Remove shadow if it's inside another card */
            border-radius: 0;
            background: none;
        }
        .attendance-history-card table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .attendance-history-card th, .attendance-history-card td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .attendance-history-card th {
            background-color: #f9fafb;
            font-weight: 600;
            color: var(--text-light);
            text-transform: uppercase;
            font-size: 13px;
        }
        .attendance-history-card tbody tr:last-child td {
            border-bottom: none;
        }
        .attendance-history-card tbody tr:hover {
            background-color: #f9fafb;
        }
        .logout-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
        }

        /* Status colors for employee attendance */
        .status.present { background-color: #e8f5e9; color: #2E7D32; } /* Green */
        .status.absent { background-color: #ffebee; color: #C62828; } /* Red */
        .status.late { background-color: #fff3e0; color: #FF6F00; } /* Amber */
        .status.leave { background-color: #e3f2fd; color: #1565C0; } /* Blue */

        @media (max-width: 768px) {
            body.attendance-body {
                padding: 15px;
            }
            .attendance-card, .attendance-history-card {
                padding: 20px;
            }
            .attendance-card h2, .attendance-history-card h2 {
                font-size: 20px;
            }
            .attendance-history-card td:before { /* Mobile table labels */
                width: 35%;
            }
            .attendance-history-card td:nth-of-type(1):before { content: "Date:"; }
            .attendance-history-card td:nth-of-type(2):before { content: "Status:"; }
            .attendance-history-card td:nth-of-type(3):before { content: "Notes:"; }
            .attendance-history-card td:nth-of-type(4):before { content: "Actions:"; display: none;} /* No actions for employee self-attendance */
            .attendance-history-card td {
                padding-left: 40%;
            }
        }
    </style>
</head>
<body class="attendance-body">
    <div class="attendance-container">
        <div class="attendance-card">
            <h2>Welcome, <span><?php echo htmlspecialchars($employee_name); ?></span>!</h2>
            <p class="welcome-message">Record your daily attendance here.</p>

            <?php if ($message): ?>
                <div class="message <?php echo $message_type; ?>">
                    <i class="fas <?php echo ($message_type == 'success' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="employee_self_attendance.php">
                <input type="hidden" name="employee_id" value="<?php echo htmlspecialchars($logged_in_employee_id); ?>">

                <div class="form-group">
                    <label for="attendance_date">Date:</label>
                    <input type="date" id="attendance_date" name="attendance_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="status">Status:</label>
                    <select id="status" name="status" required>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                        <option value="Late">Late</option>
                        <option value="Leave">Leave</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="notes">Notes (Optional):</label>
                    <textarea id="notes" name="notes" rows="3" placeholder="e.g., Working remotely, on vacation..."></textarea>
                </div>

                <button type="submit" name="submit_attendance">Record Attendance</button>
            </form>
        </div>

        <div class="attendance-history-card">
            <h2>Your Recent Attendance History</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($employee_attendance_history)): ?>
                            <tr>
                                <td colspan="3" style="text-align: center;">No attendance records found for you.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($employee_attendance_history as $record): ?>
                                <tr>
                                    <td><?php echo date('Y-m-d', strtotime($record['attendance_date'])); ?></td>
                                    <td>
                                        <span class="status <?php echo strtolower($record['status']); ?>">
                                            <?php echo htmlspecialchars($record['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($record['notes']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <a href="employee_logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</body>
</html>