<?php
include 'header.php'; // Includes session_start(), login check, and initial HTML

// --- Load Data from Session ---
// Ensure all necessary session data is loaded.
$employees = $_SESSION['employee_data'] ?? [];
$inventory_items = $_SESSION['inventory_data'] ?? [];
$orders = $_SESSION['order_data'] ?? [];

// --- Helper Functions for Calculations ---

// 1. Employee Report Calculations
function getEmployeeReport($employees) {
    $total_employees = count($employees);
    $total_salary_bill = 0;
    $roles_count = [];
    $shifts_count = [];

    foreach ($employees as $emp) {
        $total_salary_bill += $emp['salary'];
        $roles_count[$emp['role']] = ($roles_count[$emp['role']] ?? 0) + 1;
        $shifts_count[$emp['shift']] = ($shifts_count[$emp['shift']] ?? 0) + 1;
    }

    $avg_salary = $total_employees > 0 ? $total_salary_bill / $total_employees : 0;

    return [
        'total_employees' => $total_employees,
        'total_salary_bill' => $total_salary_bill,
        'average_salary' => $avg_salary,
        'roles_distribution' => $roles_count,
        'shifts_distribution' => $shifts_count,
    ];
}

// 2. Inventory Report Calculations
function getInventoryReport($inventory_items) {
    $total_items = count($inventory_items);
    $total_inventory_value = 0;
    $stock_status_count = ['In Stock' => 0, 'Low Stock' => 0, 'Out of Stock' => 0];
    $critical_items = []; // Items with Low Stock or Out of Stock

    foreach ($inventory_items as $item) {
        $total_inventory_value += ($item['quantity'] * $item['price_per_unit']);
        $stock_status_count[$item['status']] = ($stock_status_count[$item['status']] ?? 0) + 1;
        if ($item['status'] == 'Low Stock' || $item['status'] == 'Out of Stock') {
            $critical_items[] = $item;
        }
    }

    return [
        'total_unique_items' => $total_items,
        'total_inventory_value' => $total_inventory_value,
        'stock_status_distribution' => $stock_status_count,
        'critical_stock_items' => $critical_items,
    ];
}

// 3. Order Report Calculations
function getOrderReport($orders) {
    $total_orders = count($orders);
    $status_count = ['Pending' => 0, 'Accepted' => 0, 'Completed' => 0];
    $overdue_orders = [];
    $upcoming_deliveries = [];
    $today = date('Y-m-d');

    foreach ($orders as $order) {
        $status_count[$order['status']] = ($status_count[$order['status']] ?? 0) + 1;

        if ($order['status'] != 'Completed' && $order['delivery_date'] < $today) {
            $overdue_orders[] = $order;
        }

        // Upcoming deliveries within the next 7 days (and not completed)
        $delivery_timestamp = strtotime($order['delivery_date']);
        $today_timestamp = strtotime($today);
        $seven_days_later_timestamp = strtotime('+7 days', $today_timestamp);

        if ($order['status'] != 'Completed' && $delivery_timestamp >= $today_timestamp && $delivery_timestamp <= $seven_days_later_timestamp) {
            $upcoming_deliveries[] = $order;
        }
    }

    return [
        'total_orders' => $total_orders,
        'order_status_distribution' => $status_count,
        'overdue_orders' => $overdue_orders,
        'upcoming_deliveries_7_days' => $upcoming_deliveries,
    ];
}

// --- Generate Reports ---
$employee_report = getEmployeeReport($employees);
$inventory_report = getInventoryReport($inventory_items);
$order_report = getOrderReport($orders);

?>

<?php include 'sidebar.php'; // Includes the sidebar navigation ?>

<div class="main-content">
    <h1>Factory Reports</h1>

    <div class="reports-container">

        <div class="report-card">
            <h3>Employee Overview</h3>
            <p>Summary of workforce distribution and salaries.</p>
            <div class="report-details">
                <p><strong>Total Employees:</strong> <?php echo $employee_report['total_employees']; ?></p>
                <p><strong>Total Monthly Salary Bill:</strong> $<?php echo number_format($employee_report['total_salary_bill'], 2); ?></p>
                <p><strong>Average Salary:</strong> $<?php echo number_format($employee_report['average_salary'], 2); ?></p>

                <h4>Roles Distribution:</h4>
                <ul>
                    <?php if (empty($employee_report['roles_distribution'])): ?>
                        <li>No roles found.</li>
                    <?php else: ?>
                        <?php foreach ($employee_report['roles_distribution'] as $role => $count): ?>
                            <li><?php echo htmlspecialchars($role); ?>: <?php echo $count; ?></li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>

                <h4>Shift Distribution:</h4>
                <div class="bar-chart-container">
                    <?php
                    $max_shift_count = 0;
                    if (!empty($employee_report['shifts_distribution'])) {
                         $max_shift_count = max($employee_report['shifts_distribution']);
                    }
                    if ($max_shift_count == 0 && !empty($employee_report['shifts_distribution'])) $max_shift_count = 1; // Prevent division by zero if all counts are 0

                    if (empty($employee_report['shifts_distribution'])): ?>
                        <p>No shifts found.</p>
                    <?php else: ?>
                        <?php foreach ($employee_report['shifts_distribution'] as $shift => $count): ?>
                            <div class="bar-item">
                                <span class="bar-label"><?php echo htmlspecialchars($shift); ?> (<?php echo $count; ?>)</span>
                                <div class="bar" style="width: <?php echo ($max_shift_count > 0) ? ($count / $max_shift_count * 100) : 0; ?>%;"></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div>
            <div class="report-actions">
                <a href="#" class="btn-download"><i class="fas fa-download"></i> Download PDF</a>
            </div>
        </div>

        <div class="report-card">
            <h3>Inventory Valuation & Status</h3>
            <p>Current stock levels, value, and critical items.</p>
            <div class="report-details">
                <p><strong>Total Unique Items:</strong> <?php echo $inventory_report['total_unique_items']; ?></p>
                <p><strong>Total Inventory Value:</strong> $<?php echo number_format($inventory_report['total_inventory_value'], 2); ?></p>

                <h4>Stock Status Distribution:</h4>
                <ul>
                    <?php if (empty($inventory_report['stock_status_distribution'])): ?>
                        <li>No stock data.</li>
                    <?php else: ?>
                        <?php foreach ($inventory_report['stock_status_distribution'] as $status => $count): ?>
                            <li><?php echo htmlspecialchars($status); ?>: <?php echo $count; ?></li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>

                <h4>Critical Stock Items:</h4>
                <?php if (empty($inventory_report['critical_stock_items'])): ?>
                    <p>No critical stock items at the moment.</p>
                <?php else: ?>
                    <ul class="critical-list">
                        <?php foreach ($inventory_report['critical_stock_items'] as $item): ?>
                            <li><?php echo htmlspecialchars($item['material_name']); ?> (Qty: <?php echo $item['quantity']; ?>) - <span class="status <?php echo strtolower(str_replace(' ', '-', $item['status'])); ?>"><?php echo htmlspecialchars($item['status']); ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="report-actions">
                <a href="#" class="btn-download"><i class="fas fa-download"></i> Download PDF</a>
            </div>
        </div>

        <div class="report-card">
            <h3>Order Fulfillment & Status</h3>
            <p>Overview of open, completed, and upcoming orders.</p>
            <div class="report-details">
                <p><strong>Total Orders:</strong> <?php echo $order_report['total_orders']; ?></p>

                <h4>Order Status Distribution:</h4>
                <ul>
                    <?php if (empty($order_report['order_status_distribution'])): ?>
                        <li>No orders found.</li>
                    <?php else: ?>
                        <?php foreach ($order_report['order_status_distribution'] as $status => $count): ?>
                            <li><?php echo htmlspecialchars($status); ?>: <?php echo $count; ?></li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>

                <h4>Overdue Orders:</h4>
                <?php if (empty($order_report['overdue_orders'])): ?>
                    <p>No overdue orders.</p>
                <?php else: ?>
                    <ul class="critical-list">
                        <?php foreach ($order_report['overdue_orders'] as $order): ?>
                            <li><?php echo htmlspecialchars($order['order_id']); ?> for <?php echo htmlspecialchars($order['client_name']); ?> (Due: <?php echo date('M d, Y', strtotime($order['delivery_date'])); ?>)</li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <h4>Upcoming Deliveries (Next 7 Days):</h4>
                <?php if (empty($order_report['upcoming_deliveries_7_days'])): ?>
                    <p>No upcoming deliveries in the next 7 days.</p>
                <?php else: ?>
                    <ul class="upcoming-list">
                        <?php foreach ($order_report['upcoming_deliveries_7_days'] as $order): ?>
                            <li><?php echo htmlspecialchars($order['order_id']); ?> for <?php echo htmlspecialchars($order['client_name']); ?> (On: <?php echo date('M d, Y', strtotime($order['delivery_date'])); ?>)</li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="report-actions">
                <a href="#" class="btn-download"><i class="fas fa-download"></i> Download PDF</a>
            </div>
        </div>

    </div>
</div>

</div> </body>
</html>