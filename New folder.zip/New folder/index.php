<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factory OS - Login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body class="login-body">
    <div class="login-container">
        <div class="login-box">
            <img src="logo.png" alt="Factory OS Logo" class="logo">
            <h1>FACTORY OS</h1>
            <p class="welcome-text">Welcome Back</p>

            <?php
                // Display error message if login fails (for demonstration)
                if (isset($_GET['error'])) {
                    echo '<p class="error-message">Invalid username or password (Demo Mode).</p>';
                }
            ?>

            <form action="login_process.php" method="post">
                <div class="input-group">
                    <input type="text" id="username" name="username" placeholder="Username" required>
                </div>
                <div class="input-group">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit">LOGIN</button>
            </form>
            <a href="#" class="forgot-password">Forgot Password?</a>
        </div>
    </div>
</body>
</html>