<?php
// Include database connection FIRST to establish database connection ($conn)
// and make log_activity() function available.
include 'config.php';
// Then include header.php which handles session_start() and login checks.
include 'header.php';

$message = '';
$message_type = '';

// --- Handle Form Submissions (Add, Edit, Delete Item) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_item'])) {
        $material_name = htmlspecialchars($_POST['material_name']);
        $quantity = htmlspecialchars($_POST['quantity']);
        $price_per_unit = htmlspecialchars($_POST['price_per_unit']);
        $status = htmlspecialchars($_POST['status']);

        if (!empty($material_name) && is_numeric($quantity) && $quantity >= 0 && is_numeric($price_per_unit) && $price_per_unit >= 0) {
            $sql = "INSERT INTO inventory (material_name, quantity, price_per_unit, status) VALUES (?, ?, ?, ?)";
            // Prepare a NEW statement for this specific ADD operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sids", $material_name, $quantity, $price_per_unit, $status); // s=string, i=integer, d=double
                if ($stmt->execute()) {
                    $new_item_id = $stmt->insert_id;
                    $message = "Item added successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'inventory_added', "New item '" . $material_name . "' was added to inventory.", $new_item_id);
                } else {
                    $message = "Error adding item: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['edit_item'])) {
        $id = htmlspecialchars($_POST['item_id']);
        $material_name = htmlspecialchars($_POST['material_name']);
        $quantity = htmlspecialchars($_POST['quantity']);
        $price_per_unit = htmlspecialchars($_POST['price_per_unit']);
        $status = htmlspecialchars($_POST['status']);

        if (!empty($id) && is_numeric($id) && !empty($material_name) && is_numeric($quantity) && $quantity >= 0 && is_numeric($price_per_unit) && $price_per_unit >= 0) {
            $sql = "UPDATE inventory SET material_name = ?, quantity = ?, price_per_unit = ?, status = ? WHERE id = ?";
            // Prepare a NEW statement for this specific EDIT operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sidsi", $material_name, $quantity, $price_per_unit, $status, $id);
                if ($stmt->execute()) {
                    $message = "Item updated successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'inventory_updated', "Inventory item '" . $material_name . "' (ID: " . $id . ") was updated.", $id);
                } else {
                    $message = "Error updating item: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly for editing.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['delete_item'])) {
        $id = htmlspecialchars($_POST['item_id']);

        if (!empty($id) && is_numeric($id)) {
             // First, get item name for logging before deletion
            $item_name_to_delete = "Unknown";
            $sql_get_name = "SELECT material_name FROM inventory WHERE id = ?";
            $stmt_get_name = $conn->prepare($sql_get_name);
            if($stmt_get_name){
                $stmt_get_name->bind_param("i", $id);
                $stmt_get_name->execute();
                $result_name = $stmt_get_name->get_result();
                if($row_name = $result_name->fetch_assoc()){
                    $item_name_to_delete = $row_name['material_name'];
                }
                $stmt_get_name->close();
            }

            $sql = "DELETE FROM inventory WHERE id = ?";
            // Prepare a NEW statement for this specific DELETE operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    $message = "Item deleted successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'inventory_deleted', "Inventory item '" . $item_name_to_delete . "' (ID: " . $id . ") was deleted.", $id);
                } else {
                    $message = "Error deleting item: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Invalid item ID for deletion.";
            $message_type = 'error';
        }
    }
}

// --- Fetch Inventory Items for Display ---
$inventory_items = [];
$sql_fetch = "SELECT id, material_name, quantity, price_per_unit, status FROM inventory ORDER BY material_name ASC";
if ($result = $conn->query($sql_fetch)) {
    while ($row = $result->fetch_assoc()) {
        $inventory_items[] = $row;
    }
    $result->free();
} else {
    // Only set message if there was a problem fetching, not just no items
    if (empty($inventory_items) && $conn->error) {
        $message = "Error fetching inventory items: " . $conn->error;
        $message_type = 'error';
    }
}
?>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Inventory Management</h1>

    <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>">
            <i class="fas <?php echo ($message_type == 'success' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <button class="btn-add" onclick="openAddModal()"><i class="fas fa-plus"></i> Add New Item</button>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Material Name</th>
                    <th>Quantity</th>
                    <th>Price Per Unit</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($inventory_items)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">No inventory items found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($inventory_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['material_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                            <td>$<?php echo number_format($item['price_per_unit'], 2); ?></td>
                            <td><span class="status <?php echo strtolower(str_replace(' ', '-', $item['status'])); ?>"><?php echo htmlspecialchars($item['status']); ?></span></td>
                            <td>
                                <button class="btn-edit" onclick="openEditModal(
                                    <?php echo $item['id']; ?>,
                                    '<?php echo htmlspecialchars($item['material_name'], ENT_QUOTES); ?>',
                                    '<?php echo htmlspecialchars($item['quantity']); ?>',
                                    '<?php echo htmlspecialchars($item['price_per_unit']); ?>',
                                    '<?php echo htmlspecialchars($item['status'], ENT_QUOTES); ?>'
                                )"><i class="fas fa-edit"></i> Edit</button>
                                <form method="POST" action="inventory.php" style="display:inline-block;">
                                    <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($item['id']); ?>">
                                    <button type="submit" name="delete_item" class="btn-delete" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeAddModal()">&times;</span>
            <h2>Add Inventory Item</h2>
            <form method="POST" action="inventory.php">
                <div class="form-group">
                    <label for="add_material_name">Material Name</label>
                    <input type="text" id="add_material_name" name="material_name" required>
                </div>
                <div class="form-group">
                    <label for="add_quantity">Quantity</label>
                    <input type="number" id="add_quantity" name="quantity" required>
                </div>
                <div class="form-group">
                    <label for="add_price_per_unit">Price Per Unit</label>
                    <input type="number" id="add_price_per_unit" name="price_per_unit" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="add_status">Status</label>
                    <select id="add_status" name="status" required>
                        <option value="In Stock">In Stock</option>
                        <option value="Low Stock">Low Stock</option>
                        <option value="Out of Stock">Out of Stock</option>
                    </select>
                </div>
                <button type="submit" name="add_item" class="btn-modal-save">Add Item</button>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeEditModal()">&times;</span>
            <h2>Edit Inventory Item</h2>
            <form method="POST" action="inventory.php">
                <input type="hidden" id="edit_item_id" name="item_id">
                <div class="form-group">
                    <label for="edit_material_name">Material Name</label>
                    <input type="text" id="edit_material_name" name="material_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_quantity">Quantity</label>
                    <input type="number" id="edit_quantity" name="quantity" required>
                </div>
                <div class="form-group">
                    <label for="edit_price_per_unit">Price Per Unit</label>
                    <input type="number" id="edit_price_per_unit" name="price_per_unit" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="edit_status">Status</label>
                    <select id="edit_status" name="status" required>
                        <option value="In Stock">In Stock</option>
                        <option value="Low Stock">Low Stock</option>
                        <option value="Out of Stock">Out of Stock</option>
                    </select>
                </div>
                <button type="submit" name="edit_item" class="btn-modal-save">Save Changes</button>
            </form>
        </div>
    </div>

</div>

<script>
    function openAddModal() { document.getElementById('addModal').style.display = 'block'; }
    function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }
    function openEditModal(id, material_name, quantity, price_per_unit, status) {
        document.getElementById('edit_item_id').value = id;
        document.getElementById('edit_material_name').value = material_name;
        document.getElementById('edit_quantity').value = quantity;
        document.getElementById('edit_price_per_unit').value = price_per_unit;
        document.getElementById('edit_status').value = status;
        document.getElementById('editModal').style.display = 'block';
    }
    function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

    window.onclick = function(event) {
        if (event.target == document.getElementById('addModal')) { closeAddModal(); }
        if (event.target == document.getElementById('editModal')) { closeEditModal(); }
    }
</script>
<script>
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (mobileMenuToggle && sidebar && sidebarOverlay) {
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });

        // Close sidebar if window is resized to desktop size
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) { // Assuming 768px is our mobile breakpoint
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            }
        });
    }
</script>
</body>
</html>