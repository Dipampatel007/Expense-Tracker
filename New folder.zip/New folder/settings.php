<?php
// Include database connection FIRST, so $conn is available immediately.
include 'config.php'; // <--- Ensure config.php is included here
session_start(); // Then start the session

// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: index.php");
    exit;
}

// Initialize variables
$message = '';
$message_type = '';
$settings = [];
$admin_name = '';
$admin_email = '';

// --- Fetch all current settings from the database ---
// Now $conn should be available here
$sql_fetch = "SELECT setting_key, setting_value FROM settings";
if ($result = $conn->query($sql_fetch)) { // Line 13: This is where the error likely occurred
    while ($row = $result->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    $result->free();
} else {
    // Add error handling for database query
    $message = "Error fetching settings: " . $conn->error;
    $message_type = 'error';
}

// Populate admin details from settings array for easier access
$admin_name = $settings['admin_name'] ?? 'Admin User';
$admin_email = $settings['admin_email'] ?? 'admin@example.com';


// --- Handle Form Submissions ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Use a prepared statement to prevent SQL injection for updates
    $sql_update = "UPDATE settings SET setting_value = ? WHERE setting_key = ?";
    $stmt = $conn->prepare($sql_update); // Using $conn here

    if ($stmt) {
        // --- 1. General Settings Form ---
        if (isset($_POST['save_general_settings'])) {
            $factory_name = htmlspecialchars($_POST['factory_name']);
            $timezone = htmlspecialchars($_POST['timezone']);
            $currency = htmlspecialchars($_POST['currency_symbol']);

            // Bind and execute for each setting
            $stmt->bind_param("ss", $factory_name, $key_factory);
            $key_factory = 'factory_name';
            $stmt->execute();

            $stmt->bind_param("ss", $timezone, $key_tz);
            $key_tz = 'timezone';
            $stmt->execute();

            $stmt->bind_param("ss", $currency, $key_curr);
            $key_curr = 'currency_symbol';
            $stmt->execute();

            $message = "General settings saved successfully!";
            $message_type = 'success';
        }

        // --- 2. Profile Settings Form ---
        if (isset($_POST['save_profile_settings'])) {
            $admin_name_post = htmlspecialchars($_POST['admin_name']);
            $admin_email_post = htmlspecialchars($_POST['admin_email']);

            $stmt->bind_param("ss", $admin_name_post, $key_name);
            $key_name = 'admin_name';
            $stmt->execute();

            $stmt->bind_param("ss", $admin_email_post, $key_email);
            $key_email = 'admin_email';
            $stmt->execute();

            $message = "Profile settings updated successfully!";
            $message_type = 'success';
        }

        // --- 3. Notification Settings Form ---
        if (isset($_POST['save_notification_settings'])) {
            $notify_low_stock = isset($_POST['notify_low_stock']) ? '1' : '0';
            $notify_new_order = isset($_POST['notify_new_order']) ? '1' : '0';

            $stmt->bind_param("ss", $notify_low_stock, $key_low_stock);
            $key_low_stock = 'notify_low_stock';
            $stmt->execute();

            $stmt->bind_param("ss", $notify_new_order, $key_new_order);
            $key_new_order = 'notify_new_order';
            $stmt->execute();

            $message = "Notification preferences saved!";
            $message_type = 'success';
        }

        $stmt->close();
    } else {
        $message = "Error preparing statement: " . $conn->error;
        $message_type = 'error';
    }

    // --- 4. Password Change Form ---
    if (isset($_POST['change_password'])) {
        // For simplicity, we'll just update the password for the 'admin' user.
        // A real system would use the logged-in user's ID.
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if ($new_password === $confirm_password && !empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql_pass_update = "UPDATE users SET password = ? WHERE username = 'admin'";
            $stmt_pass = $conn->prepare($sql_pass_update); // Using $conn here
            if ($stmt_pass) {
                $stmt_pass->bind_param("s", $hashed_password);
                $stmt_pass->execute();
                $stmt_pass->close();
                $message = "Password changed successfully!";
                $message_type = 'success';
            } else {
                $message = "Error changing password: " . $conn->error;
                $message_type = 'error';
            }
        } else {
            $message = "Passwords do not match or are empty.";
            $message_type = 'error';
        }
    }

    // Re-fetch settings after update to display the new values
    // Using $conn here
    if ($result = $conn->query("SELECT setting_key, setting_value FROM settings")) {
        while ($row = $result->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $result->free();
    }
}
session_write_close();
?>

<?php include 'header.php'; // Include header after all PHP logic to ensure $conn is global ?>
<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Settings</h1>

    <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="settings-grid">
        <div class="setting-card">
            <h3>Profile Settings</h3>
            <form method="POST" action="settings.php">
                <div class="form-group">
                    <label for="admin_name">Admin Name</label>
                    <input type="text" id="admin_name" name="admin_name" value="<?php echo htmlspecialchars($settings['admin_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="admin_email">Admin Email</label>
                    <input type="email" id="admin_email" name="admin_email" value="<?php echo htmlspecialchars($settings['admin_email'] ?? ''); ?>">
                </div>
                <button type="submit" name="save_profile_settings" class="btn-save">Save Profile</button>
            </form>
        </div>

        <div class="setting-card">
            <h3>Change Password</h3>
            <form method="POST" action="settings.php">
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" placeholder="Enter new password">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password">
                </div>
                <button type="submit" name="change_password" class="btn-save">Change Password</button>
            </form>
        </div>

        <div class="setting-card">
            <h3>Application Settings</h3>
            <form method="POST" action="settings.php">
                <div class="form-group">
                    <label for="factory_name">Factory Name</label>
                    <input type="text" id="factory_name" name="factory_name" value="<?php echo htmlspecialchars($settings['factory_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="timezone">Timezone</label>
                    <select id="timezone" name="timezone">
                        <option value="Asia/Kolkata" <?php echo (($settings['timezone'] ?? '') == 'Asia/Kolkata') ? 'selected' : ''; ?>>Asia/Kolkata (IST)</option>
                        <option value="America/New_York" <?php echo (($settings['timezone'] ?? '') == 'America/New_York') ? 'selected' : ''; ?>>America/New York (EST)</option>
                        <option value="Europe/London" <?php echo (($settings['timezone'] ?? '') == 'Europe/London') ? 'selected' : ''; ?>>Europe/London (GMT)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="currency_symbol">Currency Symbol</label>
                    <input type="text" id="currency_symbol" name="currency_symbol" value="<?php echo htmlspecialchars($settings['currency_symbol'] ?? ''); ?>">
                </div>
                <button type="submit" name="save_general_settings" class="btn-save">Save Settings</button>
            </form>
        </div>

        <div class="setting-card">
            <h3>Notification Settings</h3>
            <form method="POST" action="settings.php">
                <div class="form-group toggle-group">
                    <label for="notify_low_stock">Low Stock Alerts</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="notify_low_stock" name="notify_low_stock" <?php echo (($settings['notify_low_stock'] ?? '0') == '1') ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="form-group toggle-group">
                    <label for="notify_new_order">New Order Alerts</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="notify_new_order" name="notify_new_order" <?php echo (($settings['notify_new_order'] ?? '0') == '1') ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </label>
                </div>
                <button type="submit" name="save_notification_settings" class="btn-save">Save Preferences</button>
            </form>
        </div>

        <div class="setting-card">
            <h3>System Actions</h3>
            <div class="system-actions">
                <p>Perform maintenance tasks. Use with caution.</p>
                <button class="btn-action">
                    <i class="fas fa-broom"></i> Clear System Cache
                </button>
                <button class="btn-action">
                    <i class="fas fa-database"></i> Backup Database
                </button>
                <button class="btn-danger">
                    <i class="fas fa-exclamation-triangle"></i> Factory Reset Data
                </button>
            </div>
        </div>

    </div>
</div>

</div> </body>
</html>