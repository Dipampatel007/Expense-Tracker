<?php
// Database credentials
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'factory_db');

// Attempt to connect to MySQL database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>
<?php
// --- config.php ---
// ... (your existing database connection code is at the top) ...

// --- Activity Logging Function ---
function log_activity($conn, $type, $message, $related_id = null) {
    $sql = "INSERT INTO activity_log (activity_type, activity_message, related_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssi", $type, $message, $related_id);
        $stmt->execute();
        $stmt->close();
    } else {
        // Log error to a file for debugging, don't stop the script
        error_log("Failed to prepare activity log statement: " . $conn->error);
    }
}
?>