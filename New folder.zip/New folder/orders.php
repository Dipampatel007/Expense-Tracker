<?php
// Include database connection FIRST to establish database connection ($conn)
// and make log_activity() function available.
include 'config.php';
// Then include header.php which handles session_start() and login checks.
include 'header.php';

$message = '';
$message_type = '';

// --- Handle Form Submissions (Add, Edit, Delete Order) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_order'])) {
        $order_id_val = htmlspecialchars($_POST['order_id_val']);
        $client_name = htmlspecialchars($_POST['client_name']);
        $quantity = htmlspecialchars($_POST['quantity']);
        $delivery_date = htmlspecialchars($_POST['delivery_date']);
        $status = htmlspecialchars($_POST['status']);

        if (!empty($order_id_val) && !empty($client_name) && is_numeric($quantity) && $quantity > 0 && !empty($delivery_date)) {
            $sql = "INSERT INTO orders (order_id, client_name, quantity, delivery_date, status) VALUES (?, ?, ?, ?, ?)";
            // Prepare a NEW statement for this specific ADD operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssiss", $order_id_val, $client_name, $quantity, $delivery_date, $status);
                if ($stmt->execute()) {
                    $new_order_db_id = $stmt->insert_id;
                    $message = "Order added successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'order_added', "New order '" . $order_id_val . "' for client '" . $client_name . "' was created.", $new_order_db_id);
                } else {
                    $message = "Error adding order: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['edit_order'])) {
        $id = htmlspecialchars($_POST['order_edit_id']);
        $order_id_val = htmlspecialchars($_POST['order_id_val']);
        $client_name = htmlspecialchars($_POST['client_name']);
        $quantity = htmlspecialchars($_POST['quantity']);
        $delivery_date = htmlspecialchars($_POST['delivery_date']);
        $status = htmlspecialchars($_POST['status']);

        if (!empty($id) && is_numeric($id) && !empty($order_id_val) && !empty($client_name) && is_numeric($quantity) && $quantity > 0 && !empty($delivery_date)) {
            $sql = "UPDATE orders SET order_id = ?, client_name = ?, quantity = ?, delivery_date = ?, status = ? WHERE id = ?";
            // Prepare a NEW statement for this specific EDIT operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssissi", $order_id_val, $client_name, $quantity, $delivery_date, $status, $id);
                if ($stmt->execute()) {
                    $message = "Order updated successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'order_updated', "Order '" . $order_id_val . "' (ID: " . $id . ") was updated.", $id);
                } else {
                    $message = "Error updating order: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Please fill all required fields correctly for editing.";
            $message_type = 'error';
        }

    } elseif (isset($_POST['delete_order'])) {
        $id = htmlspecialchars($_POST['order_db_id']);

        if (!empty($id) && is_numeric($id)) {
            // First, get order details for logging before deletion
            $order_id_to_delete = "Unknown";
            $sql_get_name = "SELECT order_id FROM orders WHERE id = ?";
            $stmt_get_name = $conn->prepare($sql_get_name);
            if ($stmt_get_name) {
                $stmt_get_name->bind_param("i", $id);
                $stmt_get_name->execute();
                $result_name = $stmt_get_name->get_result();
                if ($row_name = $result_name->fetch_assoc()) {
                    $order_id_to_delete = $row_name['order_id'];
                }
                $stmt_get_name->close();
            }

            $sql = "DELETE FROM orders WHERE id = ?";
            // Prepare a NEW statement for this specific DELETE operation
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    $message = "Order deleted successfully!";
                    $message_type = 'success';
                    // Log the activity
                    log_activity($conn, 'order_deleted', "Order '" . $order_id_to_delete . "' (ID: " . $id . ") was deleted.", $id);
                } else {
                    $message = "Error deleting order: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close(); // Close this statement ONLY after its use
            } else {
                $message = "Database error: Could not prepare statement.";
                $message_type = 'error';
            }
        } else {
            $message = "Invalid order ID for deletion.";
            $message_type = 'error';
        }
    }
}

// --- Fetch Orders for Display ---
$orders = [];
$sql_fetch = "SELECT id, order_id, client_name, quantity, delivery_date, status FROM orders ORDER BY id DESC";
if ($result = $conn->query($sql_fetch)) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    $result->free();
} else {
    // Only set message if there was a problem fetching, not just no orders
    if (empty($orders) && $conn->error) {
        $message = "Error fetching orders: " . $conn->error;
        $message_type = 'error';
    }
}
?>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Order Management</h1>

    <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>">
            <i class="fas <?php echo ($message_type == 'success' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <button class="btn-add" onclick="openAddModal()"><i class="fas fa-plus"></i> Add New Order</button>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>DB ID</th>
                    <th>Order ID</th>
                    <th>Client Name</th>
                    <th>Quantity</th>
                    <th>Delivery Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">No orders found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                            <td><?php echo htmlspecialchars($order['client_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($order['delivery_date'])); ?></td>
                            <td><span class="status <?php echo strtolower($order['status']); ?>"><?php echo htmlspecialchars($order['status']); ?></span></td>
                            <td>
                                <button class="btn-edit" onclick="openEditModal(
                                    <?php echo $order['id']; ?>,
                                    '<?php echo htmlspecialchars($order['order_id'], ENT_QUOTES); ?>',
                                    '<?php echo htmlspecialchars($order['client_name'], ENT_QUOTES); ?>',
                                    '<?php echo htmlspecialchars($order['quantity']); ?>',
                                    '<?php echo date('Y-m-d', strtotime($order['delivery_date'])); ?>',
                                    '<?php echo htmlspecialchars($order['status'], ENT_QUOTES); ?>'
                                )"><i class="fas fa-edit"></i> Edit</button>
                                <form method="POST" action="orders.php" style="display:inline-block;">
                                    <input type="hidden" name="order_db_id" value="<?php echo htmlspecialchars($order['id']); ?>">
                                    <button type="submit" name="delete_order" class="btn-delete" onclick="return confirm('Are you sure you want to delete this order?');"><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeAddModal()">&times;</span>
            <h2>Add New Order</h2>
            <form method="POST" action="orders.php">
                <div class="form-group">
                    <label for="add_order_id_val">Order ID</label>
                    <input type="text" id="add_order_id_val" name="order_id_val" required>
                </div>
                <div class="form-group">
                    <label for="add_client_name">Client Name</label>
                    <input type="text" id="add_client_name" name="client_name" required>
                </div>
                <div class="form-group">
                    <label for="add_quantity">Quantity</label>
                    <input type="number" id="add_quantity" name="quantity" required min="1">
                </div>
                <div class="form-group">
                    <label for="add_delivery_date">Delivery Date</label>
                    <input type="date" id="add_delivery_date" name="delivery_date" required>
                </div>
                <div class="form-group">
                    <label for="add_status">Status</label>
                    <select id="add_status" name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Completed">Completed</option>
                    </select>
                </div>
                <button type="submit" name="add_order" class="btn-modal-save">Add Order</button>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeEditModal()">&times;</span>
            <h2>Edit Order</h2>
            <form method="POST" action="orders.php">
                <input type="hidden" id="edit_order_edit_id" name="order_edit_id">
                <div class="form-group">
                    <label for="edit_order_id_val">Order ID</label>
                    <input type="text" id="edit_order_id_val" name="order_id_val" required>
                </div>
                <div class="form-group">
                    <label for="edit_client_name">Client Name</label>
                    <input type="text" id="edit_client_name" name="client_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_quantity">Quantity</label>
                    <input type="number" id="edit_quantity" name="quantity" required min="1">
                </div>
                <div class="form-group">
                    <label for="edit_delivery_date">Delivery Date</label>
                    <input type="date" id="edit_delivery_date" name="delivery_date" required>
                </div>
                <div class="form-group">
                    <label for="edit_status">Status</label>
                    <select id="edit_status" name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Completed">Completed</option>
                    </select>
                </div>
                <button type="submit" name="edit_order" class="btn-modal-save">Save Changes</button>
            </form>
        </div>
    </div>

</div>

<script>
    function openAddModal() {
        document.getElementById('add_delivery_date').valueAsDate = new Date(); // Set default delivery date to today
        document.getElementById('addModal').style.display = 'block';
    }
    function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }
    function openEditModal(id, orderId, client, quantity, delivery, status) {
        document.getElementById('edit_order_edit_id').value = id;
        document.getElementById('edit_order_id_val').value = orderId;
        document.getElementById('edit_client_name').value = client;
        document.getElementById('edit_quantity').value = quantity;
        document.getElementById('edit_delivery_date').value = delivery;
        document.getElementById('edit_status').value = status;
        document.getElementById('editModal').style.display = 'block';
    }
    function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

    window.onclick = function(event) {
        if (event.target == document.getElementById('addModal')) { closeAddModal(); }
        if (event.target == document.getElementById('editModal')) { closeEditModal(); }
    }
</script>
<script>
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (mobileMenuToggle && sidebar && sidebarOverlay) {
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });

        // Close sidebar if window is resized to desktop size
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) { // Assuming 768px is our mobile breakpoint
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            }
        });
    }
</script>
</body>
</html>